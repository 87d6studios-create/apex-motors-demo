/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback } from 'react';
import {
  WorkshopState,
  NewEnquiryInput,
  EnquiryStatus,
  ServicePackage,
  GalleryItem,
  loadWorkshopState,
  saveWorkshopState,
  createInitialWorkshopState,
  addEnquiry,
  updateEnquiryStatus,
  upsertServicePackage,
  deleteServicePackage,
  addGalleryItem,
  deleteGalleryItem,
} from './data/workshopStore';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ServicesSection } from './components/ServicesSection';
import { PricingSection } from './components/PricingSection';
import { GallerySection } from './components/GallerySection';
import { BookingSection } from './components/BookingSection';
import { LocationSection } from './components/LocationSection';
import { AdminModal } from './components/AdminModal';

export default function App() {
  const [state, setState] = useState<WorkshopState>(() => loadWorkshopState());
  const [preselectedService, setPreselectedService] = useState<string>('');
  const [isAdminOpen, setIsAdminOpen] = useState<boolean>(false);

  useEffect(() => {
    saveWorkshopState(state);
  }, [state]);

  const scrollToSection = useCallback((sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, []);

  const handleSelectServiceForBooking = useCallback(
    (serviceName: string) => {
      setPreselectedService(serviceName);
      scrollToSection('booking');
    },
    [scrollToSection]
  );

  const handleSubmitEnquiry = useCallback((input: NewEnquiryInput) => {
    setState((prev) => addEnquiry(prev, input));
  }, []);

  const handleUpdateEnquiryStatus = useCallback(
    (id: string, status: EnquiryStatus) => {
      setState((prev) => updateEnquiryStatus(prev, id, status));
    },
    []
  );

  const handleUpsertService = useCallback(
    (pkg: Omit<ServicePackage, 'id' | 'code'> & { id?: string; code?: string }) => {
      setState((prev) => upsertServicePackage(prev, pkg));
    },
    []
  );

  const handleDeleteService = useCallback((id: string) => {
    setState((prev) => deleteServicePackage(prev, id));
  }, []);

  const handleAddGalleryItem = useCallback((item: Omit<GalleryItem, 'id'>) => {
    setState((prev) => addGalleryItem(prev, item));
  }, []);

  const handleDeleteGalleryItem = useCallback((id: string) => {
    setState((prev) => deleteGalleryItem(prev, id));
  }, []);

  const handleResetDemoData = useCallback(() => {
    const fresh = createInitialWorkshopState();
    setState(fresh);
    saveWorkshopState(fresh);
  }, []);

  return (
    <div className="min-h-screen bg-[#0B0D10] text-[#F3F4F6] flex flex-col">
      <Navbar
        workshopTitle={state.workshopTitle}
        onBookClick={() => scrollToSection('booking')}
      />

      <main className="flex-1">
        <HeroSection
          heroImageUrl={state.heroImageUrl}
          onPrimaryBookClick={() => scrollToSection('booking')}
          onExplorePricingClick={() => scrollToSection('pricing')}
        />

        <ServicesSection
          onSelectServiceForBooking={handleSelectServiceForBooking}
        />

        <PricingSection
          services={state.services}
          customRepairs={state.customRepairs}
          onSelectServiceForBooking={handleSelectServiceForBooking}
        />

        <GallerySection gallery={state.gallery} />

        <BookingSection
          services={state.services}
          customRepairs={state.customRepairs}
          preselectedService={preselectedService}
          onSubmitEnquiry={handleSubmitEnquiry}
          onOpenAdminFromConfirmation={() => setIsAdminOpen(true)}
        />

        <LocationSection
          workshopTitle={state.workshopTitle}
          enquiriesCount={state.enquiries.length}
          onOpenAdmin={() => setIsAdminOpen(true)}
          onBookClick={() => scrollToSection('booking')}
        />
      </main>

      <AdminModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        state={state}
        onUpdateEnquiryStatus={handleUpdateEnquiryStatus}
        onUpsertService={handleUpsertService}
        onDeleteService={handleDeleteService}
        onAddGalleryItem={handleAddGalleryItem}
        onDeleteGalleryItem={handleDeleteGalleryItem}
        onResetDemoData={handleResetDemoData}
      />
    </div>
  );
}

