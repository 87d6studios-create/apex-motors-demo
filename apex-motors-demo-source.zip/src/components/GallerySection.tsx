import React, { useState } from 'react';
import { Maximize2, X, ChevronLeft, ChevronRight, Camera } from 'lucide-react';
import { GalleryItem } from '../data/workshopStore';

interface GallerySectionProps {
  gallery: GalleryItem[];
}

export const GallerySection: React.FC<GallerySectionProps> = ({ gallery }) => {
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [failedIds, setFailedIds] = useState<Record<string, boolean>>({});

  const activeItem =
    selectedIndex !== null && gallery[selectedIndex] ? gallery[selectedIndex] : null;

  const handlePrev = () => {
    if (selectedIndex === null || gallery.length === 0) return;
    setSelectedIndex((selectedIndex - 1 + gallery.length) % gallery.length);
  };

  const handleNext = () => {
    if (selectedIndex === null || gallery.length === 0) return;
    setSelectedIndex((selectedIndex + 1) % gallery.length);
  };

  return (
    <section id="gallery" className="py-20 lg:py-24 bg-[#0B0D10] border-b border-white/10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-12">
          <div className="max-w-2xl">
            <p className="text-xs font-medium text-[#F59E0B] tracking-wide mb-2">
              Inside Our Jaipur Studio
            </p>
            <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-tight text-balance">
              Diagnostic Bays & Detailing Architecture
            </h2>
            <p className="text-sm sm:text-base text-neutral-400 mt-3 leading-relaxed">
              Inspect our dust-sealed ceramic coating booth, oscilloscope telemetry stations, and 3D laser alignment racks. Click any bay photograph to open a full-resolution preview.
            </p>
          </div>

          <p className="text-xs font-mono-tabular text-neutral-400 shrink-0">
            {gallery.length} Curated Bay Photographs
          </p>
        </div>

        {gallery.length === 0 ? (
          <div className="bg-[#14181F] border border-white/10 rounded-xl p-12 text-center">
            <Camera className="w-10 h-10 text-neutral-500 mx-auto mb-3" aria-hidden="true" />
            <p className="text-base font-semibold text-white">No workshop photographs in gallery</p>
            <p className="text-xs text-neutral-400 mt-1">
              Use the Workshop Admin panel in the footer to add new gallery images.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {gallery.map((item, idx) => {
              const hasFailed = Boolean(failedIds[item.id]);
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setSelectedIndex(idx)}
                  aria-label={`Preview gallery photo: ${item.title}`}
                  className="group relative text-left bg-[#14181F] border border-white/10 hover:border-[#F59E0B]/60 rounded-xl overflow-hidden transition-colors duration-200 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#F59E0B]"
                >
                  <div className="aspect-[4/3] w-full overflow-hidden bg-[#0B0D10] relative">
                    {!hasFailed ? (
                      <img
                        src={item.imageUrl}
                        alt={item.title}
                        referrerPolicy="no-referrer"
                        onError={() =>
                          setFailedIds((prev) => ({ ...prev, [item.id]: true }))
                        }
                        className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-[#14181F] via-[#0B0D10] to-[#1F170E] flex flex-col items-center justify-center p-6 text-center">
                        <Camera className="w-10 h-10 text-[#F59E0B]/60 mb-2" aria-hidden="true" />
                        <span className="text-xs text-neutral-300 font-medium">
                          {item.title}
                        </span>
                      </div>
                    )}
                    <div
                      className="absolute inset-0 bg-gradient-to-t from-[#0B0D10] via-[#0B0D10]/25 to-transparent"
                      aria-hidden="true"
                    />
                    <div className="absolute top-4 right-4 p-2 rounded-md bg-[#0B0D10]/80 border border-white/15 text-neutral-200 group-hover:text-[#F59E0B] transition-colors">
                      <Maximize2 className="w-4 h-4" aria-hidden="true" />
                    </div>
                  </div>

                  <div className="p-5 sm:p-6">
                    <p className="text-xs text-neutral-400 mb-1">
                      <span className="text-[#F59E0B]">{item.category}</span>
                      <span className="mx-1.5" aria-hidden="true">·</span>
                      <span>{item.baySpec}</span>
                    </p>
                    <h3 className="font-display text-lg font-bold text-white group-hover:text-[#F59E0B] transition-colors">
                      {item.title}
                    </h3>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Lightbox Modal Preview */}
      {activeItem && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={`Lightbox preview: ${activeItem.title}`}
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-8"
          onClick={() => setSelectedIndex(null)}
        >
          <div
            className="relative max-w-4xl w-full bg-[#14181F] border border-white/15 rounded-xl overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
              <div>
                <p className="text-xs text-neutral-400">
                  <span className="text-[#F59E0B]">{activeItem.category}</span>
                  <span className="mx-1.5" aria-hidden="true">·</span>
                  <span>{activeItem.baySpec}</span>
                </p>
                <h3 className="font-display text-base sm:text-lg font-bold text-white">
                  {activeItem.title}
                </h3>
              </div>

              <button
                type="button"
                onClick={() => setSelectedIndex(null)}
                aria-label="Close lightbox preview"
                className="p-2 rounded-md bg-white/5 hover:bg-white/15 text-neutral-300 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" aria-hidden="true" />
              </button>
            </div>

            <div className="aspect-[16/10] w-full bg-[#0B0D10] relative flex items-center justify-center">
              {!failedIds[activeItem.id] ? (
                <img
                  src={activeItem.imageUrl}
                  alt={activeItem.title}
                  referrerPolicy="no-referrer"
                  className="max-h-[70vh] w-full h-full object-contain"
                />
              ) : (
                <div className="p-12 text-center">
                  <Camera className="w-12 h-12 text-[#F59E0B] mx-auto mb-3" aria-hidden="true" />
                  <p className="text-sm text-white">{activeItem.title}</p>
                </div>
              )}
            </div>

            <div className="px-6 py-4 border-t border-white/10 flex items-center justify-between">
              <span className="text-xs font-mono-tabular text-neutral-400">
                Photograph {(selectedIndex ?? 0) + 1} of {gallery.length}
              </span>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handlePrev}
                  aria-label="Previous gallery photograph"
                  className="px-3 py-1.5 text-xs font-medium bg-white/5 hover:bg-white/15 text-white rounded-md inline-flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" aria-hidden="true" />
                  <span>Previous</span>
                </button>
                <button
                  type="button"
                  onClick={handleNext}
                  aria-label="Next gallery photograph"
                  className="px-3 py-1.5 text-xs font-medium bg-white/5 hover:bg-white/15 text-white rounded-md inline-flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <span>Next</span>
                  <ChevronRight className="w-4 h-4" aria-hidden="true" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
