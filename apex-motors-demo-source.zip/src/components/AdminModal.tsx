import React, { useState } from 'react';
import {
  X,
  Lock,
  Unlock,
  Plus,
  Trash2,
  Edit3,
  Check,
  RotateCcw,
} from 'lucide-react';
import {
  WorkshopState,
  EnquiryStatus,
  ServicePackage,
  GalleryItem,
  formatINR,
  cycleEnquiryStatus,
} from '../data/workshopStore';

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: WorkshopState;
  onUpdateEnquiryStatus: (id: string, status: EnquiryStatus) => void;
  onUpsertService: (
    pkg: Omit<ServicePackage, 'id' | 'code'> & { id?: string; code?: string }
  ) => void;
  onDeleteService: (id: string) => void;
  onAddGalleryItem: (item: Omit<GalleryItem, 'id'>) => void;
  onDeleteGalleryItem: (id: string) => void;
  onResetDemoData: () => void;
}

type AdminTab = 'enquiries' | 'services' | 'gallery';

export const AdminModal: React.FC<AdminModalProps> = ({
  isOpen,
  onClose,
  state,
  onUpdateEnquiryStatus,
  onUpsertService,
  onDeleteService,
  onAddGalleryItem,
  onDeleteGalleryItem,
  onResetDemoData,
}) => {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [adminPin, setAdminPin] = useState('APEX-2026');
  const [activeTab, setActiveTab] = useState<AdminTab>('enquiries');

  // Service Editor State
  const [editingServiceId, setEditingServiceId] = useState<string | undefined>(undefined);
  const [svcTitle, setSvcTitle] = useState('');
  const [svcCategory, setSvcCategory] = useState<ServicePackage['category']>('Maintenance');
  const [svcPriceINR, setSvcPriceINR] = useState('');
  const [svcDuration, setSvcDuration] = useState('2 Hours');
  const [svcWarranty, setSvcWarranty] = useState('10,000 km Warranty');
  const [svcDescription, setSvcDescription] = useState('');
  const [svcError, setSvcError] = useState('');

  // Gallery Editor State
  const [galTitle, setGalTitle] = useState('');
  const [galCategory, setGalCategory] = useState('Ceramic Detailing');
  const [galBaySpec, setGalBaySpec] = useState('Bay 05 · Jaipur Studio');
  const [galImageUrl, setGalImageUrl] = useState(
    '/src/assets/images/gallery_ceramic_detailing_1794836950453.jpg'
  );
  const [galError, setGalError] = useState('');

  if (!isOpen) return null;

  const startEditService = (pkg: ServicePackage) => {
    setEditingServiceId(pkg.id);
    setSvcTitle(pkg.title);
    setSvcCategory(pkg.category);
    setSvcPriceINR(String(pkg.priceINR));
    setSvcDuration(pkg.duration);
    setSvcWarranty(pkg.warranty);
    setSvcDescription(pkg.description);
    setSvcError('');
  };

  const resetServiceForm = () => {
    setEditingServiceId(undefined);
    setSvcTitle('');
    setSvcCategory('Maintenance');
    setSvcPriceINR('');
    setSvcDuration('2 Hours');
    setSvcWarranty('10,000 km Warranty');
    setSvcDescription('');
    setSvcError('');
  };

  const handleSaveService = (e: React.FormEvent) => {
    e.preventDefault();
    const numericPrice = Number(svcPriceINR);
    if (!svcTitle.trim() || !Number.isFinite(numericPrice) || numericPrice < 0) {
      setSvcError('Please enter a service title and a valid INR price.');
      return;
    }

    onUpsertService({
      id: editingServiceId,
      title: svcTitle,
      category: svcCategory,
      priceINR: numericPrice,
      duration: svcDuration,
      warranty: svcWarranty,
      description:
        svcDescription ||
        'Precision workshop package with genuine OEM consumables and digital inspection report.',
      deliverables: [
        'Genuine OEM/OES specification parts & consumables',
        'Digital 64-point diagnostic health report',
      ],
    });
    resetServiceForm();
  };

  const handleAddGallery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!galTitle.trim() || !galImageUrl.trim()) {
      setGalError('Please enter both a caption and an image URL.');
      return;
    }
    onAddGalleryItem({
      title: galTitle,
      category: galCategory,
      baySpec: galBaySpec,
      imageUrl: galImageUrl,
    });
    setGalTitle('');
    setGalError('');
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Workshop Admin Dashboard"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
    >
      <div className="w-full max-w-5xl bg-[#14181F] border border-white/15 rounded-xl shadow-2xl overflow-hidden my-auto max-h-[90vh] flex flex-col">
        {/* Top Modal Header */}
        <div className="px-6 py-4 bg-[#0B0D10] border-b border-white/10 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-2.5">
            {isUnlocked ? (
              <Unlock className="w-4 h-4 text-[#F59E0B]" aria-hidden="true" />
            ) : (
              <Lock className="w-4 h-4 text-[#F59E0B]" aria-hidden="true" />
            )}
            <h2 className="font-display text-base sm:text-lg font-bold text-white">
              Apex Motors — Workshop Admin Console
            </h2>
          </div>

          <div className="flex items-center gap-3">
            {isUnlocked && (
              <button
                type="button"
                onClick={onResetDemoData}
                className="px-3 py-1.5 text-xs font-medium text-neutral-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-md inline-flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Reset Demo Data</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close Workshop Admin Console"
              className="p-1.5 rounded-md bg-white/5 hover:bg-white/15 text-neutral-300 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" aria-hidden="true" />
            </button>
          </div>
        </div>

        {/* Body: Demo Login Gate OR 3-Tab Dashboard */}
        {!isUnlocked ? (
          <div className="p-8 sm:p-12 max-w-md mx-auto text-center space-y-6">
            <div className="w-12 h-12 rounded-xl bg-[#F59E0B]/15 border border-[#F59E0B]/40 flex items-center justify-center text-[#F59E0B] mx-auto">
              <Lock className="w-6 h-6" aria-hidden="true" />
            </div>

            <div>
              <h3 className="font-display text-xl font-bold text-white">
                Service Manager Access
              </h3>
              <p className="text-xs sm:text-sm text-neutral-400 mt-1.5 leading-relaxed">
                Demo credentials are pre-filled so you can immediately test managing enquiries, live INR pricing, and workshop gallery photos. All changes save to browser storage.
              </p>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                setIsUnlocked(true);
              }}
              className="space-y-4 text-left"
            >
              <div>
                <label
                  htmlFor="admin-demo-pin"
                  className="block text-xs font-medium text-neutral-300 mb-1"
                >
                  Workshop Access Key (Pre-filled Demo)
                </label>
                <input
                  id="admin-demo-pin"
                  type="text"
                  value={adminPin}
                  onChange={(e) => setAdminPin(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm font-mono-tabular bg-[#0B0D10] border border-white/15 rounded-md text-white focus:outline-none focus:border-[#F59E0B]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#F59E0B] hover:bg-[#FBBF24] text-[#0B0D10] font-semibold text-sm rounded-md transition-colors cursor-pointer"
              >
                Unlock Admin Dashboard
              </button>
            </form>
          </div>
        ) : (
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* 3-Tab Navigation Bar */}
            <div
              role="tablist"
              aria-label="Admin Management Sections"
              className="px-6 pt-4 bg-[#0B0D10]/60 border-b border-white/10 flex flex-wrap items-center gap-2 shrink-0"
            >
              <button
                type="button"
                role="tab"
                aria-selected={activeTab === 'enquiries'}
                onClick={() => setActiveTab('enquiries')}
                className={`px-4 py-2.5 text-xs font-semibold rounded-t-md border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === 'enquiries'
                    ? 'border-[#F59E0B] text-[#F59E0B] bg-[#14181F]'
                    : 'border-transparent text-neutral-400 hover:text-white'
                }`}
              >
                Customer Enquiries ({state.enquiries.length})
              </button>

              <button
                type="button"
                role="tab"
                aria-selected={activeTab === 'services'}
                onClick={() => setActiveTab('services')}
                className={`px-4 py-2.5 text-xs font-semibold rounded-t-md border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === 'services'
                    ? 'border-[#F59E0B] text-[#F59E0B] bg-[#14181F]'
                    : 'border-transparent text-neutral-400 hover:text-white'
                }`}
              >
                Manage Services & Prices ({state.services.length})
              </button>

              <button
                type="button"
                role="tab"
                aria-selected={activeTab === 'gallery'}
                onClick={() => setActiveTab('gallery')}
                className={`px-4 py-2.5 text-xs font-semibold rounded-t-md border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeTab === 'gallery'
                    ? 'border-[#F59E0B] text-[#F59E0B] bg-[#14181F]'
                    : 'border-transparent text-neutral-400 hover:text-white'
                }`}
              >
                Manage Gallery ({state.gallery.length})
              </button>
            </div>

            {/* Scrollable Tab Content */}
            <div className="p-6 overflow-y-auto flex-1 space-y-6">
              {/* TAB 1: CUSTOMER ENQUIRIES */}
              {activeTab === 'enquiries' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <h3 className="font-display text-lg font-bold text-white">
                        Submitted Appointment Requests
                      </h3>
                      <p className="text-xs text-neutral-400">
                        Click any status button or select a state to transition between Pending, Contacted, and Completed.
                      </p>
                    </div>
                  </div>

                  <div className="divide-y divide-white/10 border border-white/10 rounded-lg bg-[#0B0D10]">
                    {state.enquiries.map((enq) => (
                      <div
                        key={enq.id}
                        className="p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                      >
                        <div className="space-y-1">
                          <p className="text-xs text-neutral-400 font-mono-tabular">
                            <strong className="text-white font-sans font-semibold text-sm">
                              {enq.customerName}
                            </strong>
                            <span className="mx-2" aria-hidden="true">·</span>
                            <span>{enq.phone}</span>
                            <span className="mx-2" aria-hidden="true">·</span>
                            <span className="text-[#F59E0B]">{enq.carModel}</span>
                            <span className="mx-2" aria-hidden="true">·</span>
                            <span>{enq.registrationNumber}</span>
                          </p>

                          <p className="text-xs sm:text-sm font-medium text-neutral-200">
                            {enq.serviceRequested}
                          </p>

                          <p className="text-xs text-neutral-400">
                            {enq.problemDescription}
                          </p>

                          <p className="text-[11px] font-mono-tabular text-neutral-400 pt-1">
                            Slot: {enq.preferredDate} · {enq.preferredTimeSlot}
                          </p>
                        </div>

                        <div className="flex items-center gap-2 shrink-0 self-start lg:self-center">
                          {(['Pending', 'Contacted', 'Completed'] as EnquiryStatus[]).map(
                            (st) => {
                              const isCurrent = enq.status === st;
                              return (
                                <button
                                  key={st}
                                  type="button"
                                  onClick={() => onUpdateEnquiryStatus(enq.id, st)}
                                  aria-label={`Set status for ${enq.customerName} to ${st}`}
                                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                                    isCurrent
                                      ? 'bg-[#F59E0B] text-[#0B0D10] font-semibold'
                                      : 'bg-white/5 text-neutral-400 hover:text-white'
                                  }`}
                                >
                                  {isCurrent ? `✓ ${st}` : st}
                                </button>
                              );
                            }
                          )}

                          <button
                            type="button"
                            onClick={() =>
                              onUpdateEnquiryStatus(
                                enq.id,
                                cycleEnquiryStatus(enq.status)
                              )
                            }
                            aria-label={`Cycle status for ${enq.customerName}`}
                            className="px-2.5 py-1.5 text-xs font-mono-tabular bg-white/10 hover:bg-white/15 text-white rounded-md cursor-pointer"
                          >
                            Next Status
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 2: MANAGE SERVICES & PRICES */}
              {activeTab === 'services' && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                  {/* Left: Add / Edit Service Form */}
                  <form
                    onSubmit={handleSaveService}
                    className="lg:col-span-5 bg-[#0B0D10] border border-white/10 rounded-lg p-5 space-y-4"
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="font-display text-base font-bold text-white">
                        {editingServiceId ? 'Edit Service Package' : 'Add New Fixed-Price Package'}
                      </h3>
                      {editingServiceId && (
                        <button
                          type="button"
                          onClick={resetServiceForm}
                          className="text-xs text-neutral-400 hover:text-white cursor-pointer"
                        >
                          Cancel Edit
                        </button>
                      )}
                    </div>

                    <div>
                      <label
                        htmlFor="admin-svc-title"
                        className="block text-xs font-medium text-neutral-300 mb-1"
                      >
                        Service Package Title *
                      </label>
                      <input
                        id="admin-svc-title"
                        type="text"
                        value={svcTitle}
                        onChange={(e) => setSvcTitle(e.target.value)}
                        placeholder="e.g., Laser Wheel Alignment & Balancing"
                        className="w-full px-3 py-2 text-xs sm:text-sm bg-[#14181F] border border-white/15 rounded-md text-white focus:outline-none focus:border-[#F59E0B]"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label
                          htmlFor="admin-svc-price"
                          className="block text-xs font-medium text-neutral-300 mb-1"
                        >
                          Fixed Price (INR ₹) *
                        </label>
                        <input
                          id="admin-svc-price"
                          type="number"
                          min="0"
                          value={svcPriceINR}
                          onChange={(e) => setSvcPriceINR(e.target.value)}
                          placeholder="e.g., 2800"
                          className="w-full px-3 py-2 text-xs sm:text-sm font-mono-tabular bg-[#14181F] border border-white/15 rounded-md text-white focus:outline-none focus:border-[#F59E0B]"
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="admin-svc-category"
                          className="block text-xs font-medium text-neutral-300 mb-1"
                        >
                          Category
                        </label>
                        <select
                          id="admin-svc-category"
                          value={svcCategory}
                          onChange={(e) =>
                            setSvcCategory(e.target.value as ServicePackage['category'])
                          }
                          className="w-full px-3 py-2 text-xs sm:text-sm bg-[#14181F] border border-white/15 rounded-md text-white focus:outline-none focus:border-[#F59E0B]"
                        >
                          <option value="Maintenance">Maintenance</option>
                          <option value="Diagnostics">Diagnostics</option>
                          <option value="Mechanical">Mechanical</option>
                          <option value="Detailing">Detailing</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label
                          htmlFor="admin-svc-duration"
                          className="block text-xs font-medium text-neutral-300 mb-1"
                        >
                          Turnaround Time
                        </label>
                        <input
                          id="admin-svc-duration"
                          type="text"
                          value={svcDuration}
                          onChange={(e) => setSvcDuration(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-[#14181F] border border-white/15 rounded-md text-white"
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="admin-svc-warranty"
                          className="block text-xs font-medium text-neutral-300 mb-1"
                        >
                          Warranty Term
                        </label>
                        <input
                          id="admin-svc-warranty"
                          type="text"
                          value={svcWarranty}
                          onChange={(e) => setSvcWarranty(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-[#14181F] border border-white/15 rounded-md text-white"
                        />
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="admin-svc-desc"
                        className="block text-xs font-medium text-neutral-300 mb-1"
                      >
                        Scope Description
                      </label>
                      <textarea
                        id="admin-svc-desc"
                        rows={2}
                        value={svcDescription}
                        onChange={(e) => setSvcDescription(e.target.value)}
                        placeholder="Describe consumables and inspections included..."
                        className="w-full px-3 py-2 text-xs bg-[#14181F] border border-white/15 rounded-md text-white"
                      />
                    </div>

                    {svcError && (
                      <p className="text-xs text-[#EF4444]" role="alert">
                        {svcError}
                      </p>
                    )}

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-[#F59E0B] hover:bg-[#FBBF24] text-[#0B0D10] font-semibold text-xs rounded-md inline-flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      {editingServiceId ? (
                        <>
                          <Check className="w-4 h-4" aria-hidden="true" />
                          <span>Save Updated Package</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-4 h-4" aria-hidden="true" />
                          <span>Publish Service Package</span>
                        </>
                      )}
                    </button>
                  </form>

                  {/* Right: Live Service Packages List */}
                  <div className="lg:col-span-7 divide-y divide-white/10 border border-white/10 rounded-lg bg-[#0B0D10]">
                    {state.services.map((pkg) => (
                      <div
                        key={pkg.id}
                        className="p-4 flex items-center justify-between gap-4"
                      >
                        <div>
                          <p className="text-xs text-neutral-400">
                            <span>{pkg.category}</span>
                            <span className="mx-1.5" aria-hidden="true">·</span>
                            <span>{pkg.duration}</span>
                          </p>
                          <p className="text-sm font-bold text-white">{pkg.title}</p>
                          <p className="font-mono-tabular text-sm font-semibold text-[#F59E0B] mt-0.5">
                            {formatINR(pkg.priceINR)}
                          </p>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => startEditService(pkg)}
                            aria-label={`Edit ${pkg.title}`}
                            className="px-3 py-1.5 text-xs bg-white/5 hover:bg-white/15 text-neutral-200 rounded-md inline-flex items-center gap-1 cursor-pointer"
                          >
                            <Edit3 className="w-3.5 h-3.5" aria-hidden="true" />
                            <span>Edit Price</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => onDeleteService(pkg.id)}
                            aria-label={`Delete ${pkg.title}`}
                            className="p-1.5 text-xs bg-white/5 hover:bg-[#DC2626] text-neutral-300 hover:text-white rounded-md transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" aria-hidden="true" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 3: MANAGE GALLERY */}
              {activeTab === 'gallery' && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                  {/* Left: Add Gallery Photo Form */}
                  <form
                    onSubmit={handleAddGallery}
                    className="lg:col-span-5 bg-[#0B0D10] border border-white/10 rounded-lg p-5 space-y-4"
                  >
                    <h3 className="font-display text-base font-bold text-white">
                      Add Workshop Photograph
                    </h3>

                    <div>
                      <label
                        htmlFor="admin-gal-title"
                        className="block text-xs font-medium text-neutral-300 mb-1"
                      >
                        Photo Caption / Title *
                      </label>
                      <input
                        id="admin-gal-title"
                        type="text"
                        value={galTitle}
                        onChange={(e) => setGalTitle(e.target.value)}
                        placeholder="e.g., Porsche 911 GT3 Ceramic Curing Booth"
                        className="w-full px-3 py-2 text-xs sm:text-sm bg-[#14181F] border border-white/15 rounded-md text-white focus:outline-none focus:border-[#F59E0B]"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="admin-gal-url"
                        className="block text-xs font-medium text-neutral-300 mb-1"
                      >
                        Image Asset Path or URL *
                      </label>
                      <input
                        id="admin-gal-url"
                        type="text"
                        value={galImageUrl}
                        onChange={(e) => setGalImageUrl(e.target.value)}
                        className="w-full px-3 py-2 text-xs font-mono-tabular bg-[#14181F] border border-white/15 rounded-md text-white focus:outline-none focus:border-[#F59E0B]"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label
                          htmlFor="admin-gal-category"
                          className="block text-xs font-medium text-neutral-300 mb-1"
                        >
                          Discipline
                        </label>
                        <input
                          id="admin-gal-category"
                          type="text"
                          value={galCategory}
                          onChange={(e) => setGalCategory(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-[#14181F] border border-white/15 rounded-md text-white"
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="admin-gal-bay"
                          className="block text-xs font-medium text-neutral-300 mb-1"
                        >
                          Bay Specification
                        </label>
                        <input
                          id="admin-gal-bay"
                          type="text"
                          value={galBaySpec}
                          onChange={(e) => setGalBaySpec(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-[#14181F] border border-white/15 rounded-md text-white"
                        />
                      </div>
                    </div>

                    {galError && (
                      <p className="text-xs text-[#EF4444]" role="alert">
                        {galError}
                      </p>
                    )}

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-[#F59E0B] hover:bg-[#FBBF24] text-[#0B0D10] font-semibold text-xs rounded-md inline-flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Plus className="w-4 h-4" aria-hidden="true" />
                      <span>Add to Live Gallery</span>
                    </button>
                  </form>

                  {/* Right: Current Gallery List */}
                  <div className="lg:col-span-7 divide-y divide-white/10 border border-white/10 rounded-lg bg-[#0B0D10]">
                    {state.gallery.map((item) => (
                      <div
                        key={item.id}
                        className="p-4 flex items-center justify-between gap-4"
                      >
                        <div className="flex items-center gap-3.5 min-w-0">
                          <img
                            src={item.imageUrl}
                            alt={item.title}
                            referrerPolicy="no-referrer"
                            className="w-14 h-11 rounded object-cover bg-[#14181F] border border-white/10 shrink-0"
                          />
                          <div className="min-w-0">
                            <p className="text-sm font-semibold text-white truncate">
                              {item.title}
                            </p>
                            <p className="text-xs text-neutral-400 truncate">
                              {item.category} · {item.baySpec}
                            </p>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => onDeleteGalleryItem(item.id)}
                          aria-label={`Remove gallery photo ${item.title}`}
                          className="p-2 text-xs bg-white/5 hover:bg-[#DC2626] text-neutral-300 hover:text-white rounded-md transition-colors shrink-0 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" aria-hidden="true" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
