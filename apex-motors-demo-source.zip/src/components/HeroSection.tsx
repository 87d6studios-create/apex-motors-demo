import React, { useState } from 'react';
import { ArrowRight, ShieldCheck, Wrench } from 'lucide-react';

interface HeroSectionProps {
  heroImageUrl: string;
  onPrimaryBookClick: () => void;
  onExplorePricingClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  heroImageUrl,
  onPrimaryBookClick,
  onExplorePricingClick,
}) => {
  const [imgError, setImgError] = useState(false);

  return (
    <section
      id="top"
      className="relative min-h-[calc(100vh-4rem)] flex flex-col justify-between bg-[#0B0D10] border-b border-white/10 overflow-hidden"
    >
      {/* Background Media with Measured Scrim */}
      <div className="absolute inset-0 z-0">
        {!imgError ? (
          <img
            src={heroImageUrl}
            alt="Apex Motors luxury automotive service studio and diagnostic bay in Jaipur"
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover object-center opacity-55 scale-100 transition-transform duration-700"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-[#14181F] via-[#0B0D10] to-[#1E1912] flex items-center justify-center">
            <Wrench className="w-24 h-24 text-white/5" aria-hidden="true" />
          </div>
        )}
        <div
          className="absolute inset-0 bg-gradient-to-r from-[#0B0D10] via-[#0B0D10]/85 to-[#0B0D10]/35"
          aria-hidden="true"
        />
        <div
          className="absolute inset-0 bg-gradient-to-t from-[#0B0D10] via-[#0B0D10]/40 to-transparent"
          aria-hidden="true"
        />
      </div>

      {/* Main Hero Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto w-full px-6 pt-16 pb-12 lg:pt-24 lg:pb-16 flex-1 flex items-center">
        <div className="max-w-3xl space-y-6">
          {/* Quiet Unboxed Regional & Certification Metadata */}
          <p className="text-xs font-medium tracking-wide text-neutral-300">
            <span>Jaipur Flagship Facility</span>
            <span className="mx-2 text-[#F59E0B]" aria-hidden="true">·</span>
            <span>German & Luxury Marque Specialists</span>
            <span className="mx-2 text-[#F59E0B]" aria-hidden="true">·</span>
            <span>ISO 9001:2015 Certified Bay</span>
          </p>

          {/* Primary Display Headline */}
          <h1
            className="font-display font-extrabold text-white tracking-tight leading-[1.08] text-balance"
            style={{ fontSize: 'clamp(2.35rem, 4.5vw, 4rem)' }}
          >
            Precision Engineering.{' '}
            <span className="text-[#F59E0B]">Master Craftsmanship.</span>
          </h1>

          {/* Concrete Value Proposition */}
          <p className="text-base sm:text-lg text-neutral-300 leading-relaxed max-w-2xl">
            Dealer-grade telemetry diagnostics, factory-spec mechanical overhauls, and climate-controlled 9H graphene ceramic detailing—backed by upfront INR pricing and itemised digital inspection reports.
          </p>

          {/* Action Row */}
          <div className="pt-2 flex flex-wrap items-center gap-4">
            <button
              type="button"
              onClick={onPrimaryBookClick}
              className="px-6 py-3.5 bg-[#F59E0B] hover:bg-[#FBBF24] text-[#0B0D10] font-semibold text-sm rounded-md transition-colors duration-150 inline-flex items-center gap-2.5 whitespace-nowrap shrink-0 cursor-pointer shadow-lg shadow-black/40"
            >
              <span>Schedule Service Slot</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>

            <button
              type="button"
              onClick={onExplorePricingClick}
              className="px-6 py-3.5 bg-[#14181F]/90 hover:bg-[#1E242E] text-white border border-white/15 font-medium text-sm rounded-md transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer"
            >
              View Fixed INR Packages
            </button>
          </div>

          {/* Direct Assurance Line */}
          <div className="pt-2 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-neutral-400">
            <span className="inline-flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#F59E0B]" aria-hidden="true" />
              100% Genuine OEM & OES Spares
            </span>
            <span aria-hidden="true">·</span>
            <span>Zero Upfront Online Payment Required</span>
            <span aria-hidden="true">·</span>
            <span>Same-Day Express Maintenance</span>
          </div>
        </div>
      </div>

      {/* Full-Width Quantitative Proof Strip */}
      <div className="relative z-10 border-t border-white/10 bg-[#14181F]/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-6 py-6 grid grid-cols-2 lg:grid-cols-4 gap-6">
          <div>
            <p className="font-mono-tabular text-2xl sm:text-3xl font-bold text-white">
              4,850+
            </p>
            <p className="text-xs text-neutral-400 mt-1">
              Luxury & Performance Vehicles Serviced in Rajasthan (2021–2026)
            </p>
          </div>
          <div>
            <p className="font-mono-tabular text-2xl sm:text-3xl font-bold text-white">
              64-Point
            </p>
            <p className="text-xs text-neutral-400 mt-1">
              OBD-II & Oscilloscope Telemetry Protocol Per Vehicle
            </p>
          </div>
          <div>
            <p className="font-mono-tabular text-2xl sm:text-3xl font-bold text-[#F59E0B]">
              100% OEM
            </p>
            <p className="text-xs text-neutral-400 mt-1">
              Parts Traceability with Old-Part Return & Digital Photos
            </p>
          </div>
          <div>
            <p className="font-mono-tabular text-2xl sm:text-3xl font-bold text-white">
              4.9 / 5.0
            </p>
            <p className="text-xs text-neutral-400 mt-1">
              Verified Client Satisfaction Across 620+ Jaipur Reviews
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
