import React from 'react';
import { Check, ArrowRight, Wrench } from 'lucide-react';
import {
  ServicePackage,
  CustomRepairCategory,
  formatINR,
} from '../data/workshopStore';

interface PricingSectionProps {
  services: ServicePackage[];
  customRepairs: CustomRepairCategory[];
  onSelectServiceForBooking: (serviceName: string) => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({
  services,
  customRepairs,
  onSelectServiceForBooking,
}) => {
  return (
    <section id="pricing" className="py-20 lg:py-24 bg-[#14181F]/40 border-b border-white/10">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Heading */}
        <div className="max-w-3xl mb-14">
          <p className="text-xs font-medium text-[#F59E0B] tracking-wide mb-2">
            Transparent Pricing & Custom Estimates
          </p>
          <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-tight text-balance">
            Upfront Fixed INR Packages & Inspection-Based Quotes
          </h2>
          <p className="text-sm sm:text-base text-neutral-400 mt-3 leading-relaxed">
            Standard preventive maintenance and detailing packages carry fixed, all-inclusive INR pricing. Complex mechanical or collision work starts with a physical bay evaluation and an itemised written estimate before any spanner touches your car.
          </p>
        </div>

        {/* Split Layout: Left = Fixed-Price Standard Packages | Right = Inspection-Based Custom Repairs */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Column 1: Fixed-Price Standard Packages (7 cols) */}
          <div className="lg:col-span-7 flex flex-col justify-between bg-[#14181F] border border-white/10 rounded-xl p-6 sm:p-8">
            <div>
              <div className="pb-6 mb-6 border-b border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="font-display text-xl font-bold text-white">
                    Fixed-Price Standard Packages
                  </h3>
                  <p className="text-xs text-neutral-400 mt-1">
                    Includes OEM-spec consumables, labour, and digital health report
                  </p>
                </div>
                <span className="text-xs font-mono-tabular text-[#F59E0B]">
                  {services.length} Active Packages
                </span>
              </div>

              <div className="divide-y divide-white/10">
                {services.map((pkg, idx) => (
                  <div key={pkg.id} className="py-6 first:pt-0 last:pb-0">
                    <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 mb-2">
                      <div>
                        <p className="text-xs text-neutral-400 mb-1">
                          <span className="font-mono-tabular text-[#F59E0B] font-semibold">
                            {pkg.code || String(idx + 1).padStart(2, '0')}.
                          </span>{' '}
                          <span>{pkg.category}</span>
                          <span className="mx-1.5" aria-hidden="true">·</span>
                          <span>{pkg.duration}</span>
                          <span className="mx-1.5" aria-hidden="true">·</span>
                          <span>{pkg.warranty}</span>
                        </p>
                        <h4 className="font-display text-lg font-bold text-white">
                          {pkg.title}
                        </h4>
                      </div>

                      <div className="sm:text-right shrink-0">
                        <p className="font-mono-tabular text-2xl font-bold text-[#F59E0B]">
                          {formatINR(pkg.priceINR)}
                        </p>
                        <p className="text-[11px] text-neutral-400">
                          All-inclusive (incl. GST)
                        </p>
                      </div>
                    </div>

                    <p className="text-sm text-neutral-300 leading-relaxed mb-4">
                      {pkg.description}
                    </p>

                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <ul className="space-y-1.5">
                        {pkg.deliverables.map((item, i) => (
                          <li
                            key={i}
                            className="text-xs text-neutral-300 flex items-center gap-2"
                          >
                            <Check className="w-3.5 h-3.5 text-[#F59E0B] shrink-0" aria-hidden="true" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>

                      <button
                        type="button"
                        onClick={() => onSelectServiceForBooking(pkg.title)}
                        className="px-4 py-2 text-xs font-semibold text-[#0B0D10] bg-[#F59E0B] hover:bg-[#FBBF24] rounded-md transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer self-start sm:self-end"
                      >
                        Select Package
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-8 pt-5 border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-neutral-400">
              <span>Prices shown for standard 4-cylinder & 6-cylinder passenger vehicles.</span>
              <span className="font-mono-tabular text-neutral-300 whitespace-nowrap shrink-0">Live Admin Synced</span>
            </div>
          </div>

          {/* Column 2: Inspection-Based Custom Repairs (5 cols) */}
          <div className="lg:col-span-5 flex flex-col justify-between bg-[#14181F] border border-white/10 rounded-xl p-6 sm:p-8">
            <div>
              <div className="pb-6 mb-6 border-b border-white/10">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="font-display text-xl font-bold text-white">
                    Inspection-Based Custom Repairs
                  </h3>
                  <Wrench className="w-5 h-5 text-[#DC2626] shrink-0" aria-hidden="true" />
                </div>
                <p className="text-xs text-neutral-400 mt-1">
                  Diagnostic bay evaluation fee is 100% waived when you approve the repair estimate.
                </p>
              </div>

              <div className="divide-y divide-white/10">
                {customRepairs.map((repair) => (
                  <div key={repair.id} className="py-5 first:pt-0 last:pb-0">
                    <div className="flex items-baseline justify-between gap-3 mb-1.5">
                      <h4 className="font-display text-base font-bold text-white">
                        <span className="font-mono-tabular text-[#F59E0B] mr-2">
                          {repair.index}.
                        </span>
                        {repair.title}
                      </h4>
                      <span className="font-mono-tabular text-xs text-neutral-300 shrink-0">
                        {repair.diagnosticFeeINR === 0
                          ? 'Free Assessment'
                          : `${formatINR(repair.diagnosticFeeINR)} Bay Check`}
                      </span>
                    </div>

                    <p className="text-xs text-neutral-400 mb-2">
                      <span>{repair.turnaround}</span>
                      <span className="mx-1.5" aria-hidden="true">·</span>
                      <span>Itemised OEM/OES Quote</span>
                    </p>

                    <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed mb-3">
                      {repair.summary}
                    </p>

                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                      <p className="text-[11px] text-neutral-400">
                        {repair.scopeItems.join(' · ')}
                      </p>

                      <button
                        type="button"
                        onClick={() => onSelectServiceForBooking(repair.bookingOptionValue)}
                        className="px-3.5 py-2 text-xs font-semibold text-white bg-white/10 hover:bg-[#F59E0B] hover:text-[#0B0D10] border border-white/15 rounded-md transition-colors duration-150 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer self-start sm:self-auto"
                      >
                        <span>Request Custom Estimate</span>
                        <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-8 pt-5 border-t border-white/10">
              <p className="text-xs text-neutral-400 leading-relaxed">
                Need emergency flatbed recovery in Jaipur? Call our service desk directly at{' '}
                <a
                  href="tel:+911412789900"
                  className="text-[#F59E0B] font-mono-tabular hover:underline"
                >
                  +91 141 278 9900
                </a>{' '}
                for priority bay intake.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
