import React from 'react';
import { MapPin, Phone, Clock, Navigation, Lock, CalendarCheck } from 'lucide-react';

interface LocationSectionProps {
  workshopTitle: string;
  enquiriesCount: number;
  onOpenAdmin: () => void;
  onBookClick: () => void;
}

export const LocationSection: React.FC<LocationSectionProps> = ({
  workshopTitle,
  enquiriesCount,
  onOpenAdmin,
  onBookClick,
}) => {
  const googleMapsDirectionsUrl =
    'https://www.google.com/maps/dir/?api=1&destination=Sitapura+Industrial+Area+Tonk+Road+Jaipur+Rajasthan+302022';

  return (
    <>
      <section id="location" className="py-20 lg:py-24 bg-[#0B0D10] border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="max-w-2xl mb-12">
            <p className="text-xs font-medium text-[#F59E0B] tracking-wide mb-2">
              Flagship Facility & Directions
            </p>
            <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-tight text-balance">
              Visit Our Jaipur Service Studio
            </h2>
            <p className="text-sm sm:text-base text-neutral-400 mt-3 leading-relaxed">
              Conveniently positioned off Tonk Road with wide low-clearance supercar entry ramps, 24/7 CCTV-monitored indoor parking, and an espresso client lounge overlooking the main diagnostic floor.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            {/* Left Details Card */}
            <div className="lg:col-span-5 bg-[#14181F] border border-white/10 rounded-xl p-6 sm:p-8 flex flex-col justify-between space-y-6">
              <div className="space-y-6">
                <div>
                  <h3 className="font-display text-xl font-bold text-white">
                    {workshopTitle} — Jaipur
                  </h3>
                  <p className="text-xs text-neutral-400 mt-1">
                    Authorized Independent Luxury & Performance Workshop
                  </p>
                </div>

                <div className="space-y-4 text-sm">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-4 h-4 text-[#F59E0B] mt-1 shrink-0" aria-hidden="true" />
                    <div>
                      <p className="font-semibold text-white">Workshop Address</p>
                      <p className="text-neutral-300 text-xs sm:text-sm mt-0.5 leading-relaxed">
                        Plot G-148, Phase II, Sitapura Industrial Area, Main Tonk Road, Jaipur, Rajasthan 302022
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Clock className="w-4 h-4 text-[#F59E0B] mt-1 shrink-0" aria-hidden="true" />
                    <div>
                      <p className="font-semibold text-white">Operating Hours</p>
                      <p className="text-neutral-300 text-xs sm:text-sm mt-0.5 font-mono-tabular">
                        Monday – Sunday: 09:00 AM – 07:30 PM
                      </p>
                      <p className="text-neutral-400 text-xs mt-0.5">
                        24/7 Flatbed Recovery & Secure Night Drop-Off Available
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Phone className="w-4 h-4 text-[#F59E0B] mt-1 shrink-0" aria-hidden="true" />
                    <div>
                      <p className="font-semibold text-white">Direct Service Desk</p>
                      <a
                        href="tel:+911412789900"
                        className="text-[#F59E0B] font-mono-tabular text-sm hover:underline block mt-0.5"
                      >
                        +91 141 278 9900
                      </a>
                      <a
                        href="tel:+919829074110"
                        className="text-neutral-300 font-mono-tabular text-xs hover:text-white block mt-0.5"
                      >
                        Advisor Hotline: +91 98290 74110
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-6 border-t border-white/10 flex flex-wrap items-center gap-3">
                <a
                  href={googleMapsDirectionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-5 py-2.5 bg-[#F59E0B] hover:bg-[#FBBF24] text-[#0B0D10] font-semibold text-xs rounded-md transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0"
                >
                  <Navigation className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Get Directions</span>
                </a>

                <a
                  href="tel:+911412789900"
                  className="px-4 py-2.5 bg-white/5 hover:bg-white/10 text-white border border-white/15 font-medium text-xs rounded-md transition-colors whitespace-nowrap shrink-0"
                >
                  Call Service Advisor
                </a>
              </div>
            </div>

            {/* Right Embedded Google Maps Iframe (Jaipur, Rajasthan) */}
            <div className="lg:col-span-7 bg-[#14181F] border border-white/10 rounded-xl overflow-hidden min-h-[360px] lg:h-full relative">
              <iframe
                title="Apex Motors Jaipur Location Map"
                src="https://www.google.com/maps?q=Sitapura+Industrial+Area,Jaipur,Rajasthan&output=embed"
                className="w-full h-full min-h-[360px] border-0 opacity-90 contrast-125 grayscale-[25%]"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Quiet Footer with Subtle Workshop Admin Toggle */}
      <footer className="bg-[#0B0D10] pt-12 pb-24 md:pb-12 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <p className="font-display text-base font-extrabold text-white tracking-tight">
              {workshopTitle}
            </p>
            <p className="text-xs text-neutral-400 mt-1">
              © {new Date().getFullYear()} {workshopTitle} Jaipur. Precision Automotive Engineering & Detailing Studio.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs text-neutral-400">
            <a href="#services" className="hover:text-white transition-colors">
              Services
            </a>
            <a href="#pricing" className="hover:text-white transition-colors">
              Pricing
            </a>
            <a href="#gallery" className="hover:text-white transition-colors">
              Gallery
            </a>
            <a href="#booking" className="hover:text-white transition-colors">
              Book Slot
            </a>

            <button
              type="button"
              onClick={onOpenAdmin}
              className="px-3.5 py-2 rounded-md bg-[#14181F] hover:bg-[#1E242E] text-neutral-200 border border-white/15 inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5 text-[#F59E0B]" aria-hidden="true" />
              <span>Workshop Admin ({enquiriesCount})</span>
            </button>
          </div>
        </div>
      </footer>

      {/* Mobile-First Sticky Bottom Action Bar (strictly <= 52px height to respect 15% mobile viewport cap) */}
      <div
        role="region"
        aria-label="Quick Mobile Actions"
        className="md:hidden fixed bottom-0 inset-x-0 z-30 h-13 bg-[#0B0D10]/95 backdrop-blur-md border-t border-white/15 px-4 flex items-center justify-between gap-3"
      >
        <button
          type="button"
          onClick={onBookClick}
          className="flex-1 h-10 bg-[#F59E0B] hover:bg-[#FBBF24] text-[#0B0D10] font-semibold text-xs rounded-md inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
        >
          <CalendarCheck className="w-4 h-4" aria-hidden="true" />
          <span>Book Service</span>
        </button>

        <a
          href={googleMapsDirectionsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 h-10 bg-[#14181F] text-white border border-white/15 font-medium text-xs rounded-md inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
        >
          <Navigation className="w-4 h-4 text-[#F59E0B]" aria-hidden="true" />
          <span>Directions</span>
        </a>
      </div>
    </>
  );
};
