import React, { useState, useEffect } from 'react';
import { CheckCircle2, Calendar, Clock, PhoneCall, RotateCcw } from 'lucide-react';
import {
  ServicePackage,
  CustomRepairCategory,
  NewEnquiryInput,
  validateEnquiryInput,
  formatINR,
} from '../data/workshopStore';

interface BookingSectionProps {
  services: ServicePackage[];
  customRepairs: CustomRepairCategory[];
  preselectedService: string;
  onSubmitEnquiry: (input: NewEnquiryInput) => void;
  onOpenAdminFromConfirmation: () => void;
}

const TIME_SLOTS = [
  '09:30 AM – 11:30 AM (Morning Express Bay)',
  '12:00 PM – 02:30 PM (Midday Diagnostic Slot)',
  '03:00 PM – 05:30 PM (Afternoon Mechanical Slot)',
  '06:00 PM – 07:30 PM (Evening Drop-Off)',
];

export const BookingSection: React.FC<BookingSectionProps> = ({
  services,
  customRepairs,
  preselectedService,
  onSubmitEnquiry,
  onOpenAdminFromConfirmation,
}) => {
  const defaultService =
    preselectedService ||
    (services[0] ? services[0].title : 'Express Synthetic Oil & Filter Service');

  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [carModel, setCarModel] = useState('');
  const [registrationNumber, setRegistrationNumber] = useState('');
  const [serviceRequested, setServiceRequested] = useState(defaultService);
  const [problemDescription, setProblemDescription] = useState('');
  const [preferredDate, setPreferredDate] = useState('2026-11-18');
  const [preferredTimeSlot, setPreferredTimeSlot] = useState(TIME_SLOTS[0]);

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submittedRecord, setSubmittedRecord] = useState<NewEnquiryInput | null>(null);

  useEffect(() => {
    if (preselectedService) {
      setServiceRequested(preselectedService);
      setSubmittedRecord(null);
    }
  }, [preselectedService]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload: NewEnquiryInput = {
      customerName,
      phone,
      carModel,
      registrationNumber,
      serviceRequested,
      problemDescription,
      preferredDate,
      preferredTimeSlot,
    };

    const validation = validateEnquiryInput(payload);
    if (!validation.valid) {
      setErrors(validation.errors);
      return;
    }

    setErrors({});
    onSubmitEnquiry(payload);
    setSubmittedRecord(payload);
  };

  const handleResetForm = () => {
    setCustomerName('');
    setPhone('');
    setCarModel('');
    setRegistrationNumber('');
    setProblemDescription('');
    setErrors({});
    setSubmittedRecord(null);
  };

  return (
    <section id="booking" className="py-20 lg:py-24 bg-[#14181F]/50 border-b border-white/10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Column: Service Desk Process & Assurances */}
          <div className="lg:col-span-5 space-y-6">
            <div>
              <p className="text-xs font-medium text-[#F59E0B] tracking-wide mb-2">
                Priority Bay Reservation
              </p>
              <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-tight text-balance">
                Schedule Your Workshop Slot
              </h2>
              <p className="text-sm sm:text-base text-neutral-300 mt-3 leading-relaxed">
                Reserve a dedicated hoist or detailing booth in under 60 seconds. No online advance payment is required—our senior service advisor calls within 15 minutes to confirm your bay and parts readiness.
              </p>
            </div>

            <div className="bg-[#14181F] border border-white/10 rounded-xl p-6 space-y-5">
              <h3 className="font-display text-base font-bold text-white">
                How Our Intake Protocol Works
              </h3>

              <div className="space-y-4 text-xs sm:text-sm text-neutral-300">
                <div>
                  <p className="font-semibold text-white">
                    <span className="font-mono-tabular text-[#F59E0B] mr-2">01.</span>
                    Advisor Callback & VIN Parts Check
                  </p>
                  <p className="text-neutral-400 mt-0.5">
                    We verify your vehicle model and pre-allocate genuine OEM filters or diagnostic tooling before your arrival.
                  </p>
                </div>

                <div>
                  <p className="font-semibold text-white">
                    <span className="font-mono-tabular text-[#F59E0B] mr-2">02.</span>
                    15-Minute Walkaround & Tablet Job Card
                  </p>
                  <p className="text-neutral-400 mt-0.5">
                    Your car undergoes a joint walkaround inspection with paint thickness and OBD-II fault logging.
                  </p>
                </div>

                <div>
                  <p className="font-semibold text-white">
                    <span className="font-mono-tabular text-[#F59E0B] mr-2">03.</span>
                    Pay Only Upon Completion & Road-Test Sign-Off
                  </p>
                  <p className="text-neutral-400 mt-0.5">
                    Settle via UPI, corporate card, or NEFT after inspecting the old replaced components and final invoice.
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs text-neutral-400">
                <span className="inline-flex items-center gap-1.5">
                  <PhoneCall className="w-3.5 h-3.5 text-[#F59E0B]" aria-hidden="true" />
                  Direct Desk: +91 141 278 9900
                </span>
                <span>Mon–Sun · 09:00–19:30</span>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Form or Confirmation Screen */}
          <div className="lg:col-span-7 bg-[#14181F] border border-white/10 rounded-xl p-6 sm:p-8 lg:p-10">
            {submittedRecord ? (
              <div
                data-testid="booking-confirmation"
                className="py-6 space-y-6"
                role="status"
                aria-live="polite"
              >
                <div className="w-12 h-12 rounded-lg bg-[#F59E0B]/15 border border-[#F59E0B]/40 flex items-center justify-center text-[#F59E0B]">
                  <CheckCircle2 className="w-6 h-6" aria-hidden="true" />
                </div>

                <div>
                  <p className="text-xs font-mono-tabular text-[#F59E0B] mb-1">
                    Enquiry Logged · No Online Payment Required
                  </p>
                  <h3 className="font-display text-2xl font-bold text-white">
                    Appointment Request Confirmed for {submittedRecord.carModel}
                  </h3>
                  <p className="text-sm text-neutral-300 mt-2 leading-relaxed">
                    Thank you, <strong className="text-white">{submittedRecord.customerName}</strong>. A Senior Workshop Advisor at Apex Motors Jaipur will call you shortly on{' '}
                    <span className="font-mono-tabular text-white">{submittedRecord.phone}</span> to confirm your bay slot.
                  </p>
                </div>

                <div className="bg-[#0B0D10] border border-white/10 rounded-lg p-5 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-neutral-400 block">Selected Service / Estimate</span>
                    <strong className="text-white font-medium mt-0.5 block">
                      {submittedRecord.serviceRequested}
                    </strong>
                  </div>
                  <div>
                    <span className="text-neutral-400 block">Vehicle & Registration</span>
                    <strong className="text-white font-mono-tabular mt-0.5 block">
                      {submittedRecord.carModel} ({submittedRecord.registrationNumber || 'Unregistered'})
                    </strong>
                  </div>
                  <div>
                    <span className="text-neutral-400 block">Preferred Date</span>
                    <strong className="text-white font-mono-tabular mt-0.5 block">
                      {submittedRecord.preferredDate}
                    </strong>
                  </div>
                  <div>
                    <span className="text-neutral-400 block">Arrival Time Slot</span>
                    <strong className="text-white font-mono-tabular mt-0.5 block">
                      {submittedRecord.preferredTimeSlot}
                    </strong>
                  </div>
                </div>

                <div className="pt-2 flex flex-wrap items-center gap-4">
                  <button
                    type="button"
                    onClick={handleResetForm}
                    className="px-5 py-2.5 text-xs font-semibold text-[#0B0D10] bg-[#F59E0B] hover:bg-[#FBBF24] rounded-md transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Book Another Vehicle</span>
                  </button>

                  <button
                    type="button"
                    onClick={onOpenAdminFromConfirmation}
                    className="px-4 py-2.5 text-xs font-medium text-neutral-200 bg-white/5 hover:bg-white/10 border border-white/15 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    View Enquiry in Workshop Admin
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate className="space-y-5">
                <div className="pb-4 border-b border-white/10 flex items-center justify-between">
                  <h3 className="font-display text-lg font-bold text-white">
                    Vehicle & Owner Details
                  </h3>
                  <span className="text-xs text-neutral-400">* Required fields</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  {/* Customer Name */}
                  <div>
                    <label
                      htmlFor="customer-name"
                      className="block text-xs font-medium text-neutral-200 mb-1.5"
                    >
                      Customer Name *
                    </label>
                    <input
                      id="customer-name"
                      name="customerName"
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="e.g., Aarav Sharma"
                      className="w-full px-3.5 py-2.5 text-sm bg-[#0B0D10] border border-white/15 rounded-md text-white placeholder:text-neutral-500 focus:outline-none focus:border-[#F59E0B]"
                    />
                    {errors.customerName && (
                      <p className="text-xs text-[#EF4444] mt-1" role="alert">
                        {errors.customerName}
                      </p>
                    )}
                  </div>

                  {/* Phone Number */}
                  <div>
                    <label
                      htmlFor="customer-phone"
                      className="block text-xs font-medium text-neutral-200 mb-1.5"
                    >
                      Phone Number (10-digit Mobile) *
                    </label>
                    <input
                      id="customer-phone"
                      name="phone"
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="e.g., +91 98290 45112"
                      className="w-full px-3.5 py-2.5 text-sm font-mono-tabular bg-[#0B0D10] border border-white/15 rounded-md text-white placeholder:text-neutral-500 focus:outline-none focus:border-[#F59E0B]"
                    />
                    {errors.phone && (
                      <p className="text-xs text-[#EF4444] mt-1" role="alert">
                        {errors.phone}
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  {/* Car Manufacturer & Model */}
                  <div>
                    <label
                      htmlFor="car-model"
                      className="block text-xs font-medium text-neutral-200 mb-1.5"
                    >
                      Car Manufacturer & Model *
                    </label>
                    <input
                      id="car-model"
                      name="carModel"
                      type="text"
                      required
                      value={carModel}
                      onChange={(e) => setCarModel(e.target.value)}
                      placeholder="e.g., BMW 3 Series, Hyundai Creta"
                      className="w-full px-3.5 py-2.5 text-sm bg-[#0B0D10] border border-white/15 rounded-md text-white placeholder:text-neutral-500 focus:outline-none focus:border-[#F59E0B]"
                    />
                    {errors.carModel && (
                      <p className="text-xs text-[#EF4444] mt-1" role="alert">
                        {errors.carModel}
                      </p>
                    )}
                  </div>

                  {/* Vehicle Registration Number */}
                  <div>
                    <label
                      htmlFor="registration-number"
                      className="block text-xs font-medium text-neutral-200 mb-1.5"
                    >
                      Vehicle Registration Number (Optional)
                    </label>
                    <input
                      id="registration-number"
                      name="registrationNumber"
                      type="text"
                      value={registrationNumber}
                      onChange={(e) => setRegistrationNumber(e.target.value)}
                      placeholder="e.g., RJ14 CX 8899"
                      className="w-full px-3.5 py-2.5 text-sm font-mono-tabular uppercase bg-[#0B0D10] border border-white/15 rounded-md text-white placeholder:text-neutral-500 focus:outline-none focus:border-[#F59E0B]"
                    />
                  </div>
                </div>

                {/* Required Service Dropdown */}
                <div>
                  <label
                    htmlFor="service-requested"
                    className="block text-xs font-medium text-neutral-200 mb-1.5"
                  >
                    Required Service Package or Custom Inspection *
                  </label>
                  <select
                    id="service-requested"
                    name="serviceRequested"
                    value={serviceRequested}
                    onChange={(e) => setServiceRequested(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm bg-[#0B0D10] border border-white/15 rounded-md text-white focus:outline-none focus:border-[#F59E0B]"
                  >
                    <optgroup label="Fixed-Price Standard Packages">
                      {services.map((pkg) => (
                        <option key={pkg.id} value={pkg.title}>
                          {pkg.title} — {formatINR(pkg.priceINR)}
                        </option>
                      ))}
                    </optgroup>
                    <optgroup label="Inspection-Based Custom Repairs">
                      {customRepairs.map((rep) => (
                        <option key={rep.id} value={rep.bookingOptionValue}>
                          {rep.bookingOptionValue}
                        </option>
                      ))}
                    </optgroup>
                    <optgroup label="General Workshop Consultation">
                      <option value="General Diagnostic & Multi-Point Check">
                        General Diagnostic & Multi-Point Check
                      </option>
                    </optgroup>
                  </select>
                  {errors.serviceRequested && (
                    <p className="text-xs text-[#EF4444] mt-1" role="alert">
                      {errors.serviceRequested}
                    </p>
                  )}
                </div>

                {/* Problem Description / Notes */}
                <div>
                  <label
                    htmlFor="problem-description"
                    className="block text-xs font-medium text-neutral-200 mb-1.5"
                  >
                    Problem Description or Specific Instructions
                  </label>
                  <textarea
                    id="problem-description"
                    name="problemDescription"
                    rows={3}
                    value={problemDescription}
                    onChange={(e) => setProblemDescription(e.target.value)}
                    placeholder="Describe any warning lights, unusual noises, mileage interval, or specific detailing requests..."
                    className="w-full px-3.5 py-2.5 text-sm bg-[#0B0D10] border border-white/15 rounded-md text-white placeholder:text-neutral-500 focus:outline-none focus:border-[#F59E0B]"
                  />
                </div>

                {/* Preferred Date & Time Slot */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label
                      htmlFor="preferred-date"
                      className="block text-xs font-medium text-neutral-200 mb-1.5"
                    >
                      <span className="inline-flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-[#F59E0B]" aria-hidden="true" />
                        Preferred Date *
                      </span>
                    </label>
                    <input
                      id="preferred-date"
                      name="preferredDate"
                      type="date"
                      required
                      value={preferredDate}
                      onChange={(e) => setPreferredDate(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-sm font-mono-tabular bg-[#0B0D10] border border-white/15 rounded-md text-white focus:outline-none focus:border-[#F59E0B]"
                    />
                    {errors.preferredDate && (
                      <p className="text-xs text-[#EF4444] mt-1" role="alert">
                        {errors.preferredDate}
                      </p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="preferred-time-slot"
                      className="block text-xs font-medium text-neutral-200 mb-1.5"
                    >
                      <span className="inline-flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-[#F59E0B]" aria-hidden="true" />
                        Preferred Time Slot *
                      </span>
                    </label>
                    <select
                      id="preferred-time-slot"
                      name="preferredTimeSlot"
                      value={preferredTimeSlot}
                      onChange={(e) => setPreferredTimeSlot(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-sm bg-[#0B0D10] border border-white/15 rounded-md text-white focus:outline-none focus:border-[#F59E0B]"
                    >
                      {TIME_SLOTS.map((slot) => (
                        <option key={slot} value={slot}>
                          {slot}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <p className="text-xs text-neutral-400">
                    No prepayment required. Instant callback confirmation.
                  </p>

                  <button
                    type="submit"
                    className="px-6 py-3 bg-[#F59E0B] hover:bg-[#FBBF24] text-[#0B0D10] font-semibold text-sm rounded-md transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    Confirm Appointment Request
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
