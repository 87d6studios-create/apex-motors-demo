import React, { useState } from 'react';
import { ArrowUpRight } from 'lucide-react';

interface CoreDiscipline {
  id: string;
  number: string;
  title: string;
  categoryKey: string;
  tagline: string;
  description: string;
  metrics: string;
  bookingServiceLabel: string;
  colSpan: string;
  renderIcon: () => React.ReactNode;
}

const CORE_DISCIPLINES: CoreDiscipline[] = [
  {
    id: 'routine-maintenance',
    number: '01.',
    title: 'Routine Maintenance',
    categoryKey: 'Maintenance',
    tagline: 'Factory-Interval Preventive Servicing · Warranty Compliant',
    description:
      'Scheduled synthetic oil flushes, German filtration kits, laser brake caliper micrometer checks, and cooling circuit pressure tests that preserve manufacturer service history.',
    metrics: '90-Minute Express Bay · Liqui Moly / Mobil 1 Ester Oils',
    bookingServiceLabel: 'Express Synthetic Oil & Filter Service',
    colSpan: 'lg:col-span-7',
    renderIcon: () => (
      <svg className="w-7 h-7 text-[#F59E0B]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
        <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
        <circle cx="12" cy="12" r="3" />
      </svg>
    ),
  },
  {
    id: 'advanced-diagnostics',
    number: '02.',
    title: 'Advanced Diagnostics',
    categoryKey: 'Diagnostics',
    tagline: 'OEM Multiplexer Telemetry · Oscilloscope Fault Tracing',
    description:
      'Root-cause electrical and CAN-bus fault isolation using dealer-grade ISTA, Xentry, ODIS, and 4-channel PicoScope waveform analysis—eliminating guesswork part swapping.',
    metrics: '64-Point Digital Health Dossier · Live Sensor Logging',
    bookingServiceLabel: 'Comprehensive 64-Point ECU & Mechanical Inspection',
    colSpan: 'lg:col-span-5',
    renderIcon: () => (
      <svg className="w-7 h-7 text-[#F59E0B]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 12h3l3-7 4 14 3-7h5" />
        <rect x="2" y="3" width="20" height="18" rx="2" strokeOpacity="0.4" />
      </svg>
    ),
  },
  {
    id: 'mechanical-repairs',
    number: '03.',
    title: 'Mechanical Repairs',
    categoryKey: 'Mechanical',
    tagline: 'Powertrain, DSG/ZF Transmission & Air Suspension',
    description:
      'Precision overhaul of timing chain assemblies, twin-scroll turbochargers, mechatronic valve bodies, Airmatic struts, and 3D laser chassis geometry calibration.',
    metrics: '15,000 km Workmanship Warranty · Torque-Logged Fasteners',
    bookingServiceLabel: 'Precision Brake Disc & Ceramic Pad Service',
    colSpan: 'lg:col-span-5',
    renderIcon: () => (
      <svg className="w-7 h-7 text-[#F59E0B]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
        <path strokeLinecap="round" strokeLinejoin="round" d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z" />
      </svg>
    ),
  },
  {
    id: 'ceramic-detailing',
    number: '04.',
    title: 'Ceramic Detailing',
    categoryKey: 'Detailing',
    tagline: 'Multi-Stage Paint Correction · 9H Graphene & PPF Studio',
    description:
      'Dust-controlled correction booth equipped with hexagonal inspection lighting, Rupes rotary/dual-action polishers, 9H graphene ceramic matrices, and self-healing TPU paint protection film.',
    metrics: '3-Year Hydrophobic Guarantee · 90%+ Swirl Removal',
    bookingServiceLabel: 'Signature 9H Graphene Ceramic & Interior Restoration',
    colSpan: 'lg:col-span-7',
    renderIcon: () => (
      <svg className="w-7 h-7 text-[#F59E0B]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 3l1.912 5.813a2 2 0 001.275 1.275L21 12l-5.813 1.912a2 2 0 00-1.275 1.275L12 21l-1.912-5.813a2 2 0 00-1.275-1.275L3 12l5.813-1.912a2 2 0 001.275-1.275L12 3z" />
      </svg>
    ),
  },
];

interface ServicesSectionProps {
  onSelectServiceForBooking: (serviceName: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  onSelectServiceForBooking,
}) => {
  const [activeFilter, setActiveFilter] = useState<string>('All');
  const filterOptions = ['All', 'Maintenance', 'Diagnostics', 'Mechanical', 'Detailing'];

  const visibleDisciplines =
    activeFilter === 'All'
      ? CORE_DISCIPLINES
      : CORE_DISCIPLINES.filter((d) => d.categoryKey === activeFilter);

  return (
    <section id="services" className="py-20 lg:py-24 bg-[#0B0D10] border-b border-white/10">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header + Interactive Filter Bar */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl">
            <p className="text-xs font-medium text-[#F59E0B] tracking-wide mb-2">
              Core Engineering Capabilities
            </p>
            <h2 className="font-display text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-tight text-balance">
              Four Specialized Bays Under One Roof
            </h2>
            <p className="text-sm sm:text-base text-neutral-400 mt-3 leading-relaxed">
              Every vehicle enters a dedicated technical workflow—from rapid synthetic oil servicing to oscilloscope diagnostics and dust-sealed ceramic coating.
            </p>
          </div>

          {/* Interactive Segmented Filter Control */}
          <div
            role="group"
            aria-label="Filter workshop disciplines"
            className="flex flex-wrap items-center gap-1 p-1 bg-[#14181F] border border-white/10 rounded-lg self-start lg:self-auto"
          >
            {filterOptions.map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => setActiveFilter(option)}
                className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer ${
                  activeFilter === option
                    ? 'bg-[#F59E0B] text-[#0B0D10] font-semibold'
                    : 'text-neutral-300 hover:text-white'
                }`}
              >
                {option === 'All' ? 'All Bays' : option}
              </button>
            ))}
          </div>
        </div>

        {/* Asymmetric Bento Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {visibleDisciplines.map((item) => (
            <article
              key={item.id}
              className={`${
                activeFilter === 'All' ? item.colSpan : 'lg:col-span-6'
              } bg-[#14181F] border border-white/10 hover:border-[#F59E0B]/50 rounded-xl p-7 sm:p-8 flex flex-col justify-between transition-colors duration-200`}
            >
              <div>
                <div className="flex items-start justify-between gap-4 mb-6">
                  <div>
                    <p className="text-xs text-neutral-400 mb-1">
                      <span className="font-mono-tabular text-[#F59E0B] font-semibold mr-2">
                        {item.number}
                      </span>
                      <span>{item.tagline}</span>
                    </p>
                    <h3 className="font-display text-xl sm:text-2xl font-bold text-white tracking-tight">
                      {item.title}
                    </h3>
                  </div>
                  <div className="p-3 rounded-lg bg-[#0B0D10] border border-white/10 shrink-0">
                    {item.renderIcon()}
                  </div>
                </div>

                <p className="text-sm sm:text-base text-neutral-300 leading-relaxed mb-6">
                  {item.description}
                </p>
              </div>

              <div className="pt-5 border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <p className="text-xs text-neutral-400 font-mono-tabular">
                  {item.metrics}
                </p>

                <button
                  type="button"
                  onClick={() => onSelectServiceForBooking(item.bookingServiceLabel)}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#F59E0B] hover:text-[#FBBF24] transition-colors whitespace-nowrap shrink-0 cursor-pointer self-start sm:self-auto"
                >
                  <span>Book {item.title}</span>
                  <ArrowUpRight className="w-4 h-4" aria-hidden="true" />
                </button>
              </div>
            </article>
          ))}
        </div>

        {/* Attributable Client Proof Adjacent to Capabilities */}
        <div className="mt-10 pt-8 border-t border-white/10 grid grid-cols-1 md:grid-cols-2 gap-6">
          <blockquote className="bg-[#14181F]/60 border border-white/10 rounded-xl p-6">
            <p className="text-sm text-neutral-300 leading-relaxed">
              “My Audi A6 had an intermittent mechatronic fault that two dealerships quoted ₹2.4L to replace blindly. Apex Motors traced it via oscilloscope to a wiring harness solenoid in 3 hours and resolved it for a fraction of the quote.”
            </p>
            <footer className="mt-4 text-xs text-neutral-400">
              <strong className="text-white font-semibold">Harshvardhan Singhania</strong> · Managing Director, Amber Heritage Hotels · Jaipur (Audi A6 45 TFSI)
            </footer>
          </blockquote>

          <blockquote className="bg-[#14181F]/60 border border-white/10 rounded-xl p-6">
            <p className="text-sm text-neutral-300 leading-relaxed">
              “Booked the 9H Graphene Ceramic & Express Synthetic Oil package for my BMW X5. Received timestamped photos of the old filters, torque wrench readings, and a mirror-black finish that beads dust effortlessly.”
            </p>
            <footer className="mt-4 text-xs text-neutral-400">
              <strong className="text-white font-semibold">Dr. Meenakshi Choudhary</strong> · Senior Consultant Surgeon, C-Scheme · Jaipur (BMW X5 xDrive30d)
            </footer>
          </blockquote>
        </div>
      </div>
    </section>
  );
};
