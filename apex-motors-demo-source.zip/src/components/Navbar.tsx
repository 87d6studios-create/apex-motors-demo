import React from 'react';

interface NavbarProps {
  workshopTitle: string;
  onBookClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ workshopTitle, onBookClick }) => {
  return (
    <header className="sticky top-0 z-40 h-14 md:h-16 w-full bg-[#0B0D10]/90 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto h-full flex items-center justify-between gap-8 px-6">
        {/* Zone 1: Brand Title (Single text element wordmark) */}
        <a
          href="#top"
          className="text-lg font-extrabold tracking-tight text-white whitespace-nowrap shrink-0 font-display focus-visible:outline-2 focus-visible:outline-[#F59E0B]"
        >
          {workshopTitle}
        </a>

        {/* Zone 2: 4 Single-line Navigation Links */}
        <nav
          aria-label="Primary Navigation"
          className="hidden md:flex items-center gap-8 text-sm font-medium text-neutral-300"
        >
          <a
            href="#services"
            className="hover:text-white transition-colors duration-150 whitespace-nowrap shrink-0 py-1 border-b-2 border-transparent hover:border-[#F59E0B]"
          >
            Services
          </a>
          <a
            href="#pricing"
            className="hover:text-white transition-colors duration-150 whitespace-nowrap shrink-0 py-1 border-b-2 border-transparent hover:border-[#F59E0B]"
          >
            Pricing
          </a>
          <a
            href="#gallery"
            className="hover:text-white transition-colors duration-150 whitespace-nowrap shrink-0 py-1 border-b-2 border-transparent hover:border-[#F59E0B]"
          >
            Gallery
          </a>
          <a
            href="#location"
            className="hover:text-white transition-colors duration-150 whitespace-nowrap shrink-0 py-1 border-b-2 border-transparent hover:border-[#F59E0B]"
          >
            Location
          </a>
        </nav>

        {/* Zone 3: 1 Primary Action */}
        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onBookClick}
            className="px-5 py-2.5 text-xs font-semibold text-[#0B0D10] bg-[#F59E0B] hover:bg-[#FBBF24] rounded-md transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#F59E0B]"
          >
            Book Appointment
          </button>
        </div>
      </div>
    </header>
  );
};
