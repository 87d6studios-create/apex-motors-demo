export type EnquiryStatus = 'Pending' | 'Contacted' | 'Completed';

export interface ServicePackage {
  id: string;
  code: string;
  title: string;
  category: 'Maintenance' | 'Diagnostics' | 'Detailing' | 'Mechanical';
  priceINR: number;
  duration: string;
  warranty: string;
  description: string;
  deliverables: string[];
}

export interface CustomRepairCategory {
  id: string;
  index: string;
  title: string;
  turnaround: string;
  diagnosticFeeINR: number;
  summary: string;
  scopeItems: string[];
  bookingOptionValue: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  baySpec: string;
  imageUrl: string;
}

export interface CustomerEnquiry {
  id: string;
  customerName: string;
  phone: string;
  carModel: string;
  registrationNumber: string;
  serviceRequested: string;
  problemDescription: string;
  preferredDate: string;
  preferredTimeSlot: string;
  status: EnquiryStatus;
  createdAt: string;
}

export interface NewEnquiryInput {
  customerName: string;
  phone: string;
  carModel: string;
  registrationNumber?: string;
  serviceRequested: string;
  problemDescription?: string;
  preferredDate: string;
  preferredTimeSlot: string;
}

export interface WorkshopState {
  workshopTitle: string;
  heroImageUrl: string;
  services: ServicePackage[];
  customRepairs: CustomRepairCategory[];
  gallery: GalleryItem[];
  enquiries: CustomerEnquiry[];
}

export const STORAGE_KEY = 'apex_motors_jaipur_state_v1';

export const HERO_IMAGE_PATH = '/src/assets/images/hero_automotive_workshop_1794836946091.jpg';

export const INITIAL_SERVICES: ServicePackage[] = [
  {
    id: 'pkg-oil-filter',
    code: '01',
    title: 'Express Synthetic Oil & Filter Service',
    category: 'Maintenance',
    priceINR: 4499,
    duration: '90 Mins',
    warranty: '10,000 km / 1 Year',
    description:
      'Full-synthetic OEM-grade Ester oil flush with German MANN/Mahle filter replacement, sump torque verification, and 24-point fluid top-up.',
    deliverables: [
      'Fully synthetic 5W-30 / 0W-40 OEM-spec lubricant',
      'OEM oil & cabin micro-filter replacement',
      'Brake pad thickness & battery load readout',
    ],
  },
  {
    id: 'pkg-multipoint-diag',
    code: '02',
    title: 'Comprehensive 64-Point ECU & Mechanical Inspection',
    category: 'Diagnostics',
    priceINR: 2499,
    duration: '2 Hours',
    warranty: 'Digital Report Included',
    description:
      'Dealer-level OBD-II & CAN-bus telemetry scan paired with underbody suspension check, compression logging, and pre-purchase health certification.',
    deliverables: [
      'Full module fault-code & live sensor waveform scan',
      'Underbody bush, strut & steering rack inspection',
      'Printed & PDF technician estimate sheet',
    ],
  },
  {
    id: 'pkg-brake-overhaul',
    code: '03',
    title: 'Precision Brake Disc & Ceramic Pad Service',
    category: 'Mechanical',
    priceINR: 6999,
    duration: '3 Hours',
    warranty: '15,000 km Warranty',
    description:
      'Front and rear caliper servicing, rotor run-out micrometer indexing, low-dust ceramic pad installation, and DOT 4 LV hydraulic bleeding.',
    deliverables: [
      'Front OEM/Brembo-spec brake pad set & wear sensor',
      'Caliper guide pin lubrication & piston seal check',
      'Pressurized DOT 4 LV brake fluid flush',
    ],
  },
  {
    id: 'pkg-ceramic-detailing',
    code: '04',
    title: 'Signature 9H Graphene Ceramic & Interior Restoration',
    category: 'Detailing',
    priceINR: 18500,
    duration: '2 Days (Studio Cure)',
    warranty: '3-Year Hydrophobic Guarantee',
    description:
      'Three-stage rotary paint correction removing 90%+ swirl marks, followed by climate-controlled 9H graphene ceramic coating and Nappa leather conditioning.',
    deliverables: [
      '3-stage machine compounding & gloss enhancement',
      'Dual-layer 9H Graphene coat on paintwork & alloys',
      'Deep steam sanitization & leather pH conditioning',
    ],
  },
];

export const INITIAL_CUSTOM_REPAIRS: CustomRepairCategory[] = [
  {
    id: 'custom-engine',
    index: '01',
    title: 'Engine & Forced Induction Overhaul',
    turnaround: 'Inspection within 4 Hours',
    diagnosticFeeINR: 1500,
    summary:
      'Timing chain kits, turbocharger core rebuilds, injector flow matching, and cooling system restoration for European and domestic luxury powertrains.',
    scopeItems: ['Cylinder compression & borescope inspection', 'Timing chain & water pump assemblies', 'Turbocharger actuator & intercooler leak testing'],
    bookingOptionValue: 'Custom Estimate: Engine & Drivetrain Overhaul',
  },
  {
    id: 'custom-transmission',
    index: '02',
    title: 'DSG, ZF & Automatic Transmission Calibration',
    turnaround: 'Inspection within 3 Hours',
    diagnosticFeeINR: 1500,
    summary:
      'Mechatronic unit repair, dual-clutch flywheel replacement, torque converter servicing, and dynamic ATF dialysis flushing.',
    scopeItems: ['7-speed DSG & 8-speed ZF mechatronic diagnostics', 'Dual-mass flywheel & clutch pack replacement', 'Thermal ATF machine flush with OEM lifecycle fluid'],
    bookingOptionValue: 'Custom Estimate: Transmission & Clutch Calibration',
  },
  {
    id: 'custom-suspension',
    index: '03',
    title: 'Air Suspension, Steering Rack & 3D Alignment',
    turnaround: 'Same-Day Assessment',
    diagnosticFeeINR: 999,
    summary:
      'Airmatic / adaptive damper rebuilds, polyurethane control arm bushing press-fits, EPS rack repair, and Hunter 3D laser wheel geometry.',
    scopeItems: ['Air strut leak test & compressor calibration', 'Control arm, tie-rod & stabilizer link overhaul', 'Four-wheel laser camber, caster & toe indexing'],
    bookingOptionValue: 'Custom Estimate: Suspension & Steering Geometry',
  },
  {
    id: 'custom-collision',
    index: '04',
    title: 'Laser Chassis Straightening & OEM Paint Booth',
    turnaround: 'Written Estimate in 2 Hours',
    diagnosticFeeINR: 0,
    summary:
      'Insurance-approved aluminum & steel panel restoration, PPG Spectrophotometer color matching, and dust-free heated downdraft bake booth refinishing.',
    scopeItems: ['Spectrophotometer factory paint code formulation', 'Dent puller & OEM panel alignment tolerances', 'Cashless & reimbursement insurance claim assistance'],
    bookingOptionValue: 'Custom Estimate: Collision & Paint Booth Restoration',
  },
];

export const INITIAL_GALLERY: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'CAN-Bus Telemetry & Oscilloscope Bay',
    category: 'Advanced Diagnostics',
    baySpec: 'Bay 01 · OEM Multiplexer & Oscilloscope Suite',
    imageUrl: '/src/assets/images/gallery_diagnostic_bay_1794836949194.jpg',
  },
  {
    id: 'gal-2',
    title: 'Climate-Controlled 9H Ceramic Coating Studio',
    category: 'Ceramic Detailing',
    baySpec: 'Bay 02 · Dust-Free Hexagonal Inspection Lighting',
    imageUrl: '/src/assets/images/gallery_ceramic_detailing_1794836950453.jpg',
  },
  {
    id: 'gal-3',
    title: 'Twin-Turbo V8 Mechanical Calibration',
    category: 'Mechanical Repairs',
    baySpec: 'Bay 03 · Precision Torque & Powertrain Assembly',
    imageUrl: '/src/assets/images/gallery_engine_precision_1794836952353.jpg',
  },
  {
    id: 'gal-4',
    title: '3D Laser Wheel Geometry & Brake Indexing',
    category: 'Routine Maintenance',
    baySpec: 'Bay 04 · Sub-Millimeter Suspension Calibration Rack',
    imageUrl: '/src/assets/images/gallery_suspension_alignment_1794836953165.jpg',
  },
];

export const INITIAL_ENQUIRIES: CustomerEnquiry[] = [
  {
    id: 'enq-101',
    customerName: 'Vikramaditya Rathore',
    phone: '+91 98290 74110',
    carModel: 'BMW 530d M Sport',
    registrationNumber: 'RJ14 UF 0007',
    serviceRequested: 'Comprehensive 64-Point ECU & Mechanical Inspection',
    problemDescription: 'Subtle vibration under braking above 90 km/h and due for 60,000 km preventive inspection.',
    preferredDate: '2026-11-18',
    preferredTimeSlot: '10:00 AM – 12:00 PM',
    status: 'Contacted',
    createdAt: '2026-11-15T14:20:00.000Z',
  },
  {
    id: 'enq-102',
    customerName: 'Niharika Kasliwal',
    phone: '+91 94140 88219',
    carModel: 'Mercedes-Benz GLC 300',
    registrationNumber: 'RJ14 TC 4512',
    serviceRequested: 'Signature 9H Graphene Ceramic & Interior Restoration',
    problemDescription: 'Looking for full exterior swirl correction and 9H ceramic protection before wedding season.',
    preferredDate: '2026-11-19',
    preferredTimeSlot: '12:30 PM – 03:00 PM',
    status: 'Pending',
    createdAt: '2026-11-16T04:15:00.000Z',
  },
  {
    id: 'enq-103',
    customerName: 'Siddharth Singhal',
    phone: '+91 99281 30944',
    carModel: 'Hyundai Creta SX(O) Turbo',
    registrationNumber: 'RJ14 CV 9102',
    serviceRequested: 'Express Synthetic Oil & Filter Service',
    problemDescription: 'Annual synthetic oil service and AC cabin filter replacement.',
    preferredDate: '2026-11-17',
    preferredTimeSlot: '03:30 PM – 06:00 PM',
    status: 'Completed',
    createdAt: '2026-11-14T09:45:00.000Z',
  },
];

export function createInitialWorkshopState(): WorkshopState {
  return {
    workshopTitle: 'APEX MOTORS',
    heroImageUrl: HERO_IMAGE_PATH,
    services: [...INITIAL_SERVICES],
    customRepairs: [...INITIAL_CUSTOM_REPAIRS],
    gallery: [...INITIAL_GALLERY],
    enquiries: [...INITIAL_ENQUIRIES],
  };
}

export function formatINR(amount: number): string {
  if (!Number.isFinite(amount) || amount < 0) {
    return '₹0';
  }
  return '₹' + Math.round(amount).toLocaleString('en-IN');
}

export function validateEnquiryInput(
  input: Partial<NewEnquiryInput>
): { valid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};

  const name = (input.customerName ?? '').trim();
  if (name.length < 2) {
    errors.customerName = 'Please enter your full name (at least 2 characters).';
  }

  const phone = (input.phone ?? '').trim();
  const digitsOnly = phone.replace(/\D/g, '');
  if (digitsOnly.length < 10 || digitsOnly.length > 13) {
    errors.phone = 'Please enter a valid 10-digit Indian mobile number.';
  }

  const carModel = (input.carModel ?? '').trim();
  if (carModel.length < 2) {
    errors.carModel = 'Please enter your vehicle make and model (e.g., BMW 3 Series, Hyundai Creta).';
  }

  const serviceRequested = (input.serviceRequested ?? '').trim();
  if (!serviceRequested) {
    errors.serviceRequested = 'Please select a required service or custom repair estimate.';
  }

  const preferredDate = (input.preferredDate ?? '').trim();
  if (!preferredDate) {
    errors.preferredDate = 'Please select a preferred appointment date.';
  }

  const preferredTimeSlot = (input.preferredTimeSlot ?? '').trim();
  if (!preferredTimeSlot) {
    errors.preferredTimeSlot = 'Please choose a preferred arrival time slot.';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}

export function addEnquiry(
  state: WorkshopState,
  input: NewEnquiryInput,
  nowIso: string = new Date().toISOString()
): WorkshopState {
  const validation = validateEnquiryInput(input);
  if (!validation.valid) {
    throw new Error('Invalid enquiry input: ' + Object.values(validation.errors).join(' '));
  }

  const newEntry: CustomerEnquiry = {
    id: `enq-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    customerName: input.customerName.trim(),
    phone: input.phone.trim(),
    carModel: input.carModel.trim(),
    registrationNumber: (input.registrationNumber ?? '').trim().toUpperCase() || 'UNREGISTERED / NEW',
    serviceRequested: input.serviceRequested.trim(),
    problemDescription:
      (input.problemDescription ?? '').trim() ||
      'Standard scheduled appointment requested via online service desk.',
    preferredDate: input.preferredDate.trim(),
    preferredTimeSlot: input.preferredTimeSlot.trim(),
    status: 'Pending',
    createdAt: nowIso,
  };

  return {
    ...state,
    enquiries: [newEntry, ...state.enquiries],
  };
}

export function updateEnquiryStatus(
  state: WorkshopState,
  id: string,
  status: EnquiryStatus
): WorkshopState {
  return {
    ...state,
    enquiries: state.enquiries.map((enq) => (enq.id === id ? { ...enq, status } : enq)),
  };
}

export function cycleEnquiryStatus(current: EnquiryStatus): EnquiryStatus {
  if (current === 'Pending') return 'Contacted';
  if (current === 'Contacted') return 'Completed';
  return 'Pending';
}

export function upsertServicePackage(
  state: WorkshopState,
  pkgInput: Omit<ServicePackage, 'id' | 'code'> & { id?: string; code?: string }
): WorkshopState {
  const title = pkgInput.title.trim();
  const priceINR = Number(pkgInput.priceINR);
  if (!title || !Number.isFinite(priceINR) || priceINR < 0) {
    throw new Error('Service title and a valid non-negative INR price are required.');
  }

  if (pkgInput.id) {
    const existingIndex = state.services.findIndex((s) => s.id === pkgInput.id);
    if (existingIndex !== -1) {
      const updated = [...state.services];
      updated[existingIndex] = {
        ...updated[existingIndex],
        ...pkgInput,
        id: pkgInput.id,
        title,
        priceINR: Math.round(priceINR),
      };
      return { ...state, services: updated };
    }
  }

  const nextNum = state.services.length + 1;
  const code = pkgInput.code?.trim() || String(nextNum).padStart(2, '0');
  const newService: ServicePackage = {
    id: `pkg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    code,
    title,
    category: pkgInput.category,
    priceINR: Math.round(priceINR),
    duration: pkgInput.duration.trim() || '2 Hours',
    warranty: pkgInput.warranty.trim() || 'Standard Workshop Warranty',
    description: pkgInput.description.trim() || 'Precision workshop service performed with OEM-grade components.',
    deliverables:
      pkgInput.deliverables.length > 0
        ? pkgInput.deliverables
        : ['OEM specification parts & consumables', 'Master technician multi-point sign-off'],
  };

  return {
    ...state,
    services: [...state.services, newService],
  };
}

export function deleteServicePackage(state: WorkshopState, id: string): WorkshopState {
  return {
    ...state,
    services: state.services.filter((s) => s.id !== id),
  };
}

export function addGalleryItem(
  state: WorkshopState,
  item: Omit<GalleryItem, 'id'>
): WorkshopState {
  const title = item.title.trim();
  const imageUrl = item.imageUrl.trim();
  if (!title || !imageUrl) {
    throw new Error('Gallery caption and image URL are required.');
  }

  const newItem: GalleryItem = {
    id: `gal-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    title,
    category: item.category.trim() || 'Workshop Bay',
    baySpec: item.baySpec.trim() || 'Jaipur Flagship Studio · Precision Service Bay',
    imageUrl,
  };

  return {
    ...state,
    gallery: [newItem, ...state.gallery],
  };
}

export function deleteGalleryItem(state: WorkshopState, id: string): WorkshopState {
  return {
    ...state,
    gallery: state.gallery.filter((g) => g.id !== id),
  };
}

export function loadWorkshopState(): WorkshopState {
  const fallback = createInitialWorkshopState();
  if (typeof window === 'undefined' || !window.localStorage) {
    return fallback;
  }
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as Partial<WorkshopState>;
    return {
      workshopTitle: parsed.workshopTitle || fallback.workshopTitle,
      heroImageUrl: parsed.heroImageUrl || fallback.heroImageUrl,
      services: Array.isArray(parsed.services) && parsed.services.length > 0 ? parsed.services : fallback.services,
      customRepairs:
        Array.isArray(parsed.customRepairs) && parsed.customRepairs.length > 0
          ? parsed.customRepairs
          : fallback.customRepairs,
      gallery: Array.isArray(parsed.gallery) ? parsed.gallery : fallback.gallery,
      enquiries: Array.isArray(parsed.enquiries) ? parsed.enquiries : fallback.enquiries,
    };
  } catch {
    return fallback;
  }
}

export function saveWorkshopState(state: WorkshopState): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Ignore storage quota errors
  }
}
