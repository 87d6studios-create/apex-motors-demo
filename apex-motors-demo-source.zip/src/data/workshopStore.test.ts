import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createInitialWorkshopState,
  formatINR,
  validateEnquiryInput,
  addEnquiry,
  updateEnquiryStatus,
  cycleEnquiryStatus,
  upsertServicePackage,
  deleteServicePackage,
  addGalleryItem,
  deleteGalleryItem,
} from './workshopStore';

test('formatINR formats Indian Rupees with en-IN digit grouping', () => {
  assert.equal(formatINR(4499), '₹4,499');
  assert.equal(formatINR(18500), '₹18,500');
  assert.equal(formatINR(125000), '₹1,25,000');
  assert.equal(formatINR(-50), '₹0');
});

test('validateEnquiryInput rejects missing required fields and accepts valid Indian phone numbers', () => {
  const invalid = validateEnquiryInput({
    customerName: 'A',
    phone: '12345',
    carModel: '',
    serviceRequested: '',
    preferredDate: '',
    preferredTimeSlot: '',
  });
  assert.equal(invalid.valid, false);
  assert.ok(invalid.errors.customerName);
  assert.ok(invalid.errors.phone);
  assert.ok(invalid.errors.carModel);
  assert.ok(invalid.errors.serviceRequested);
  assert.ok(invalid.errors.preferredDate);
  assert.ok(invalid.errors.preferredTimeSlot);

  const valid = validateEnquiryInput({
    customerName: 'Aarav Sharma',
    phone: '+91 98290 45112',
    carModel: 'BMW 3 Series 330Li',
    registrationNumber: 'rj14 cx 8899',
    serviceRequested: 'Express Synthetic Oil & Filter Service',
    preferredDate: '2026-11-20',
    preferredTimeSlot: '10:00 AM – 12:00 PM',
  });
  assert.equal(valid.valid, true);
  assert.deepEqual(valid.errors, {});
});

test('addEnquiry prepends a new Pending enquiry with normalized registration number', () => {
  const initial = createInitialWorkshopState();
  const next = addEnquiry(
    initial,
    {
      customerName: 'Aarav Sharma',
      phone: '+91 98290 45112',
      carModel: 'BMW 3 Series',
      registrationNumber: 'rj14 cx 8899',
      serviceRequested: 'Custom Estimate: Engine & Drivetrain Overhaul',
      problemDescription: 'Cold start timing chain rattle',
      preferredDate: '2026-11-22',
      preferredTimeSlot: '10:00 AM – 12:00 PM',
    },
    '2026-11-16T06:00:00.000Z'
  );

  assert.equal(next.enquiries.length, initial.enquiries.length + 1);
  assert.equal(next.enquiries[0].customerName, 'Aarav Sharma');
  assert.equal(next.enquiries[0].registrationNumber, 'RJ14 CX 8899');
  assert.equal(next.enquiries[0].status, 'Pending');
});

test('updateEnquiryStatus and cycleEnquiryStatus transition statuses accurately', () => {
  const initial = createInitialWorkshopState();
  const targetId = initial.enquiries[0].id;
  const updated = updateEnquiryStatus(initial, targetId, 'Completed');
  assert.equal(updated.enquiries[0].status, 'Completed');

  assert.equal(cycleEnquiryStatus('Pending'), 'Contacted');
  assert.equal(cycleEnquiryStatus('Contacted'), 'Completed');
  assert.equal(cycleEnquiryStatus('Completed'), 'Pending');
});

test('upsertServicePackage updates existing price and adds new service package', () => {
  const initial = createInitialWorkshopState();
  const firstService = initial.services[0];

  const edited = upsertServicePackage(initial, {
    ...firstService,
    priceINR: 4999,
  });
  assert.equal(edited.services[0].priceINR, 4999);

  const added = upsertServicePackage(edited, {
    title: 'AC Compressor & Dual-Zone Gas Recharge',
    category: 'Maintenance',
    priceINR: 3200,
    duration: '2 Hours',
    warranty: '6 Months Warranty',
    description: 'R134a / R1234yf refrigerant recovery, vacuum leak test, and compressor oil recharge.',
    deliverables: ['Vacuum leak test', 'PAG oil & refrigerant recharge'],
  });
  assert.equal(added.services.length, initial.services.length + 1);
  assert.equal(added.services[added.services.length - 1].priceINR, 3200);

  const afterDelete = deleteServicePackage(added, firstService.id);
  assert.equal(afterDelete.services.length, initial.services.length);
});

test('addGalleryItem and deleteGalleryItem update gallery list', () => {
  const initial = createInitialWorkshopState();
  const withNewPhoto = addGalleryItem(initial, {
    title: 'Porsche 911 GT3 Paint Protection Film Bay',
    category: 'Ceramic Detailing',
    baySpec: 'Bay 05 · Self-Healing TPU Installation',
    imageUrl: '/src/assets/images/gallery_ceramic_detailing_1794836950453.jpg',
  });
  assert.equal(withNewPhoto.gallery.length, initial.gallery.length + 1);
  assert.equal(withNewPhoto.gallery[0].title, 'Porsche 911 GT3 Paint Protection Film Bay');

  const afterRemove = deleteGalleryItem(withNewPhoto, withNewPhoto.gallery[0].id);
  assert.equal(afterRemove.gallery.length, initial.gallery.length);
});
